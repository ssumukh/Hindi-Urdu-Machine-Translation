perl -C $setu/bin/sys/common/convertor-urd-1.5/convertor_indic.pl -f=ssf -l=urd -s=utf -t=wx -i=$1
