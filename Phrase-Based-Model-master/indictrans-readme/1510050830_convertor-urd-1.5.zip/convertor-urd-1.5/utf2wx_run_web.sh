perl -C /var/www/html/sampark/system/urd_hin/sampark/bin/sys/common/convertor-urd-1.5/convertor_indic.pl -f=ssf -l=urd -s=utf -t=wx -i=$1
