perl -C $setu/bin/sys/common/convertor-urd-1.5/convertor_indic.pl -f=ssf -l=urd -s=wx -t=utf -i=$1
