# include this directive for wx2utf subroutine.
use Encode;

# unicode to wx urdu
sub unicode2wx {
	my $string  = $_[0];

	# Normalize noise
	$string =~s/\x{200D}//g; # <200D> is Removed
	$string =~s/\x{200C}//g; # <200C> is Removed
	$string =~s/\x{feff}//g; # <feff> is Removed
	$string =~s/\x{0D}//g; # ^M is Removed

	# map arabic kaf to urdu kaf	
	$string =~s/\x{0643}/\x{06A9}/g;   # kaf ك => ک
        $string =~s/\x{064A}/\x{06CC}/g;   # choti yeh ي => ى
        $string =~s/\x{0649}/\x{06CC}/g;   # choti yeh ى => ى
        $string =~s/\x{0647}/\x{06BE}/g;   # do chasmi ه => ھ

	# Urdu numbers normalize
	$string =~s/\x{06F1}/\x{0661}/g;   # number 1
        $string =~s/\x{06F2}/\x{0662}/g;   # 2
        $string =~s/\x{06F3}/\x{0663}/g;   # 3
        $string =~s/\x{06F4}/\x{0664}/g;   # 4
        $string =~s/\x{06F5}/\x{0665}/g;   # 5
        $string =~s/\x{06F6}/\x{0666}/g;   # 6
        $string =~s/\x{06F7}/\x{0667}/g;   # 7
        $string =~s/\x{06F8}/\x{0668}/g;   # 8
        $string =~s/\x{06F9}/\x{0669}/g;   # 9
        $string =~s/\x{06F0}/\x{0660}/g;   # 0
	
	# Actual Mapping
	# waw with hamza
	$string =~s/\x{0624}/vY/g;   # ؤ => ٔو
	# choti-ye with hamza
	$string =~s/\x{0626}/IY/g;   # ئ => ٔى
	# badi-ye with hamza
	$string =~s/\x{06D3}/EYY/g;   # ۓ => ٔ ے
	# alif with hamza
	$string =~s/\x{0623}/aY/g;   # أ=> ٔا
	# laddu-he with hamza
	$string =~s/\x{06C0}/HY/g;   # ۀ =>ٔ ە

	$string =~s/\x{06A9}\x{06BE}/K/g;	# K کھ
	$string =~s/\x{06AF}\x{06BE}/G/g;	# G گھ
	$string =~s/\x{0686}\x{06BE}/C/g;	# C چھ
	$string =~s/\x{062c}\x{06BE}/J/g;	# J جھ
	$string =~s/\x{0679}\x{06BE}/T/g;	# T ٹھ
	$string =~s/\x{0688}\x{06BE}/D/g;	# D ڈھ 
	$string =~s/\x{062A}\x{06BE}/W/g;	# W تھ
	$string =~s/\x{062F}\x{06BE}/X/g;	# X دھ
	$string =~s/\x{067E}\x{06BE}/P/g;	# P پھ
	$string =~s/\x{0628}\x{06BE}/B/g;	# B بھ
	$string =~s/\x{0645}\x{06BE}/M/g;	# M مھ
	$string =~s/\x{0646}\x{06BE}/N/g;	# N نھ
	$string =~s/\x{0644}\x{06BE}/L/g;	# L لھ
	$string =~s/\x{0691}\x{06BE}/DY/g;	# DY ڑھ
	
	$string =~s/\x{0627}/a/g;	# a ا alif
	$string =~s/\x{0622}/A/g;	# A آ alif with madd above
	$string =~s/\x{06A9}/k/g;	# k ک
	$string =~s/\x{06AF}/g/g;	# g گ
	$string =~s/\x{0686}/c/g;	# c چ
	$string =~s/\x{062c}/j/g;	# j ج
	$string =~s/\x{0679}/t/g;	# t ٹ
	$string =~s/\x{0688}/d/g;	# d ڈ
	$string =~s/\x{062A}/w/g;	# w ت
	$string =~s/\x{062F}/x/g;	# x د
	$string =~s/\x{067E}/p/g;	# p پ
	$string =~s/\x{0628}/b/g;	# b ب
	$string =~s/\x{0645}/m/g;	# m م
	$string =~s/\x{0646}/n/g;	# n ن
	$string =~s/\x{0644}/l/g;	# l ل
	$string =~s/\x{0691}/dY/g;	# dY ڑ
	$string =~s/\x{06BA}/z/g;	# z ں
	$string =~s/\x{062B}/sY/g;	# s ث
	$string =~s/\x{0633}/s/g;	# sY س
	$string =~s/\x{0635}/sYY/g;	# sYY ص
	$string =~s/\x{0634}/S/g;	# S ش
	$string =~s/\x{062D}/h/g;	# h ح
	$string =~s/\x{062E}/KY/g;	# KY خ
	$string =~s/\x{0630}/jY/g;	# jY ذ
	$string =~s/\x{0632}/jYY/g;	# jYY ز
	$string =~s/\x{0698}/jVY/g;	# jVY ژ
	$string =~s/\x{0636}/jyy/g;	# jyy ض
	$string =~s/\x{0638}/jy/g;	# jy ظ
	$string =~s/\x{0631}/r/g;	# r ر
	$string =~s/\x{0637}/wY/g;	# wY ط
	$string =~s/\x{0639}/EY/g;	# EY ع
	$string =~s/\x{063A}/gY/g;	# gY غ
	$string =~s/\x{0641}/PY/g;	# PY ف
	$string =~s/\x{0642}/q/g;	# q ق
	$string =~s/\x{0648}/v/g;	# v و
	$string =~s/\x{06C1}/H/g;	# H ہ
	$string =~s/\x{06CC}/I/g;	# I ی
	$string =~s/\x{06D2}/E/g;	# E ے
	$string =~s/\x{0650}/i/g;	# e ِ
	$string =~s/\x{064E}/e/g;	# i  َ
	$string =~s/\x{064F}/u/g;	# u  ُ
	$string =~s/\x{0657}/U/g;	# U ٗ
	$string =~s/\x{0651}/R/g;	# R  ّ
	$string =~s/\x{0652}/Z/g;	# Z  ْ
	$string =~s/\x{0670}/qV/g;	# qV  ٰ
	$string =~s/\x{0656}/GV/g;	# GV ٖ
	$string =~s/\x{064B}/qf/g;	# qf  ً
	$string =~s/\x{064D}/qF/g;	# qF ٍ
	$string =~s/\x{06BE}/hY/g;	# hY ھ
	$string =~s/\x{0654}/Q/g;	# Q ٔ
	$string =~s/\x{0621}/QY/g;	# QY ء
	$string =~s/\x{0655}/QYY/g;	# QYY ٕ
	$string =~s/\x{06D4}/./g;	# full stop ۔
	$string =~s/\x{061B}/;/g;	# semi colon ;  ؛
	$string =~s/\x{060C}/,/g;	# comma , ،
	$string =~s/\x{061F}/?/g;	# quetion mark ?  ؟

        $string =~s/\x{0661}/1/g;   # number 1
        $string =~s/\x{0662}/2/g;   # 2
        $string =~s/\x{0663}/3/g;   # 3
        $string =~s/\x{0664}/4/g;   # 4
        $string =~s/\x{0665}/5/g;   # 5
        $string =~s/\x{0666}/6/g;   # 6
        $string =~s/\x{0667}/7/g;   # 7
        $string =~s/\x{0668}/8/g;   # 8
        $string =~s/\x{0669}/9/g;   # 9
        $string =~s/\x{0660}/0/g;   # 0

	return $string;
}

# wx to unicode urdu
sub wx2unicode {
	my $string  = $_[0];
	

	$string =~s/jyy/\x{0636}/g;	# jyy ض

	$string =~s/jVY/\x{0698}/g;	# jVY ژ

	$string =~s/QYY/\x{0655}/g;	# QYY ٕ
	$string =~s/jYY/\x{0632}/g;	# jYY ز
	$string =~s/sYY/\x{0635}/g;	# sYY ص
	# badi-ye with hamza
	$string =~s/EYY/\x{06D3}/g;   #EYY ۓ

	$string =~s/jy/\x{0638}/g;	# jy ظ

	# waw with hamza
	$string =~s/vY/\x{0624}/g;   # vY ؤ
	# choti-ye with hamza
	$string =~s/IY/\x{0626}/g;   # IY ئ
	# alif with hamza
	$string =~s/aY/\x{0623}/g;   # aY أ
	# laddu-he with hamza
	$string =~s/HY/\x{06C0}/g;   # HY ۀ

	$string =~s/QY/\x{0621}/g;	# QY ء
	$string =~s/hY/\x{06BE}/g;	# hY ھ
	$string =~s/qV/\x{0670}/g;	# qV  ٰ
	$string =~s/GV/\x{0656}/g;	#  GV ٖ
	$string =~s/qf/\x{064B}/g;	# qf  ً
	$string =~s/qF/\x{064D}/g;	# qF ٍ
	$string =~s/wY/\x{0637}/g;	# wY ط
	$string =~s/EY/\x{0639}/g;	# EY ع
	$string =~s/gY/\x{063A}/g;	# gY غ
	$string =~s/PY/\x{0641}/g;	# PY ف
	$string =~s/KY/\x{062E}/g;	# KY خ
	$string =~s/jY/\x{0630}/g;	# jY ذ
	$string =~s/sY/\x{062B}/g;	# s ث
	$string =~s/dY/\x{0691}/g;	# dY ڑ
	$string =~s/DY/\x{0691}\x{06BE}/g;	# DY ڑھ

	$string =~s/K/\x{06A9}\x{06BE}/g;	# K کھ
	$string =~s/G/\x{06AF}\x{06BE}/g;	# G گھ
	$string =~s/C/\x{0686}\x{06BE}/g;	# C چھ
	$string =~s/J/\x{062c}\x{06BE}/g;	# J جھ
	$string =~s/T/\x{0679}\x{06BE}/g;	# T ٹھ
	$string =~s/D/\x{0688}\x{06BE}/g;	# D ڈھ 
	$string =~s/W/\x{062A}\x{06BE}/g;	# W تھ
	$string =~s/X/\x{062F}\x{06BE}/g;	# X دھ
	$string =~s/P/\x{067E}\x{06BE}/g;	# P پھ
	$string =~s/B/\x{0628}\x{06BE}/g;	# B بھ
	$string =~s/M/\x{0645}\x{06BE}/g;	# M مھ
	$string =~s/N/\x{0646}\x{06BE}/g;	# N نھ
	$string =~s/L/\x{0644}\x{06BE}/g;	# L لھ

	$string =~s/a/\x{0627}/g;	# a ا alif
	$string =~s/A/\x{0622}/g;	# A آ alif with madd above
	$string =~s/k/\x{06A9}/g;	# k ک
	$string =~s/g/\x{06AF}/g;	# g گ
	$string =~s/c/\x{0686}/g;	# c چ
	$string =~s/j/\x{062c}/g;	# j ج
	$string =~s/t/\x{0679}/g;	# t ٹ
	$string =~s/d/\x{0688}/g;	# d ڈ
	$string =~s/w/\x{062A}/g;	# w ت
	$string =~s/x/\x{062F}/g;	# x د
	$string =~s/p/\x{067E}/g;	# p پ
	$string =~s/b/\x{0628}/g;	# b ب
	$string =~s/m/\x{0645}/g;	# m م
	$string =~s/n/\x{0646}/g;	# n ن
	$string =~s/l/\x{0644}/g;	# l ل
	$string =~s/z/\x{06BA}/g;	# z ں
	$string =~s/s/\x{0633}/g;	# sY س
	$string =~s/S/\x{0634}/g;	# S ش
	$string =~s/h/\x{062D}/g;	# h ح
	$string =~s/r/\x{0631}/g;	# r ر
	$string =~s/q/\x{0642}/g;	# q ق
	$string =~s/v/\x{0648}/g;	# v و
	$string =~s/H/\x{06C1}/g;	# H ہ
	$string =~s/I/\x{06CC}/g;	# I ی
	$string =~s/E/\x{06D2}/g;	# E ے
	$string =~s/i/\x{0650}/g;	# e ِ
	$string =~s/e/\x{064E}/g;	# i  َ
	$string =~s/u/\x{064F}/g;	# u  ُ
	$string =~s/U/\x{0657}/g;	# U ٗ
	$string =~s/R/\x{0651}/g;	#R  ّ
	$string =~s/Z/\x{0652}/g;	# Z  ْ
	$string =~s/Q/\x{0654}/g;	# Q ٔ
	# punctuations
	$string =~s/\./\x{06D4}/g;	# full stop ۔
	$string =~s/\;/\x{061B}/g;	# semi colon ;  ؛
	$string =~s/\,/\x{060C}/g;	# comma , ،
	$string =~s/\?/\x{061F}/g;	# quetion mark ?  ؟
	# numbers
	#$string =~s/1/\x{0661}/g;	# number 1
	#$string =~s/2/\x{0662}/g;	# 2
	#$string =~s/3/\x{0663}/g;	# 3
	#$string =~s/4/\x{0664}/g;	# 4
	#$string =~s/5/\x{0665}/g;	# 5
	#$string =~s/6/\x{0666}/g;	# 6
	#$string =~s/7/\x{0667}/g;	# 7
	#$string =~s/8/\x{0668}/g;	# 8
	#$string =~s/9/\x{0669}/g;	# 9
	#$string =~s/0/\x{0660}/g;	# 0

	return $string;
}


sub utf2wx {
	my $string = $_[0];
	my $lang = $_[1];
	#print $lang;
        # don't convert string precede by @
        #if ($string =~ /^\@.*/)
        #{
        #    return $string;
        #}
        #Convert UTF-8 string to Unicode
        $flag = utf8::decode($string);
        #Convert Unicode values with ISCII values
        #$string = &unicode2iscii($string, $lang);
        $string = &unicode2wx($string, $lang);
        #print "ISCII string: $string\n";
        #Convert ISCII to WX-Roman
        #$string = &iscii2wx($string);
        #print "Wx string : $string\n";
        return $string;
}

sub wx2utf {
	my $string = $_[0];
	my $lang = $_[1];
        #binmode (STDOUT, ":utf8");
	# don't convert string precede by @
	#if ($string =~ /^\@.*/) 
	#{
	#	return $string;
	#}
        
        # escape the other language only consider wx notation.
        utf8::decode($string);
        $firstchar = substr($string, 0, 1);
        $val = ord($firstchar);
        if ($val >= 255)
        {
            #$octet = encode("utf8",$string);
            return $string;
        } # end escape
        
	# Convert WX-Roman to ISCII
	#$string = &wx2iscii($string);
        #print "ISCII string $string\n";
	# Convert ISCII to Unicode
	#$string = &iscii2unicode($string, $lang);
	$string = &wx2unicode($string);
        #print "unicode string $string\n";
	#Convert Unicode to utf-8
	$octet = encode("utf8", $string);
	#print "UTF-8 string is: ", $string, "\n";
	return $string;	
}

1;

