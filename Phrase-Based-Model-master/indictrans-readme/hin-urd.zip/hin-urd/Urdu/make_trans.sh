file=$1 
cut -f1 $file > rom
cut -f2 $file > urd

sed -r 's/(.)/ \1/g' urd | sed 's/^ //' | sed -r 's/ ھ/ھ/g'  > z
mv z urd

sed -r 's/(.)/ \1/g' rom | sed 's/^ //' | sed -r 's/([bcdgjptsk]) h/\1h/g'  > z
mv z rom

bash runGiza++.sh urd rom urd2rom.gmap
python ~/Tools/python-misc/giza2tnt.py --i urd2rom.gmap > urd2rom.tnt 2> /tmp/a

bash runGiza++.sh rom urd rom2urd.gmap
python ~/Tools/python-misc/giza2tnt.py --i rom2urd.gmap > rom2urd.tnt 2> /tmp/a
