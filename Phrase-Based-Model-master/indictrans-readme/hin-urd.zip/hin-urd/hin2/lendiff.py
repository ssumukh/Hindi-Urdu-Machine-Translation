import re
import sys

if __name__ == "__main__":
    with open(sys.argv[1]) as fp:
        for line in fp:
            a, b, c, d = line.split()
            c = re.sub(r'[ZYVh]', r'', c)
            d = re.sub(r'([aeiou])\1', r'\1', d).replace('h', '')
            if abs(len(c) - len(d)) >= 3:
                if float(len(c))/len(d) >= 1.5:
                    sys.stderr.write(line)
                elif float(len(d))/len(c) >= 1.5:
                    sys.stderr.write(line)
                else:
                    sys.stdout.write(line)
            else:
                sys.stdout.write(line)
                
